#ifndef NODE_H
#define NODE_H

typedef struct Node{
    int data;
    struct Node *prev,*next;
}Node;

Node* createNode(int data);

void append(Node**head,int data);

void printList(Node*head);

Node* stringToLinkedList(char *str);
#endif


