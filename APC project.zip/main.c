/*
NAME:M.Karthik Kumar Reddy
DATE:1/12/2024
DESCRIPTION:APC project.
   */






#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "node.h"

#include "operations.h"


int main(int argc,char *argv[])
{
    if(argc!=4)
    {
	printf("Please pass 2 nums along with operator\n");
	return 1;
    }
    char *operator=argv[1];
    char *str1=argv[2];
    char *str2=argv[3];

    int num1,num2,num3,num4;

    num1=atoi(argv[2]);
    num2=atoi(argv[3]);
    num3=abs(num2);
    num4=abs(num1);

    Node *resultHead=NULL;

    if(strcmp(operator,"+")==0)
    {
	if((str1[0]>=48 && str1[0]<=57)&& str2[0]>=48 && str2[0]<=57)
	{
	    Node *head1=stringToLinkedList(str1);
	    Node *head2=stringToLinkedList(str2);
	addDigits(head1,head2,&resultHead);
	printf("Sum:");
	printList(resultHead);
	}
	else if((str1[0]>=48 && str1[0]<=57) && str2[0]==45)
	{
	    if(num1>num3)
	    {
		Node *head1=stringToLinkedList(str1);
		Node *head2=stringToLinkedList(str2);
		subtractDigits(head1,head2,&resultHead);
		printf("sum:");
		printList(resultHead);
	    }
	    else
	    {
		Node *head1=stringToLinkedList(str1);
		Node *head2=stringToLinkedList(str2);
		subtractDigits(head2,head1,&resultHead);
		printf("sum:-");
		printList(resultHead);
	    }
	}

    }
    else if(strcmp(operator,"-")==0)
    {
	Node *head1=stringToLinkedList(str1);
	Node *head2=stringToLinkedList(str2);
	if((str1[0]>=48 && str1[0]<=57) && (str2[0]>=48 && str2[0]<=57))
	{
	if(num1<num3)
	{
	subtractDigits(head2,head1,&resultHead);
	printf("Difference:-");
	printList(resultHead);
	}
	else
	{
	    subtractDigits(head1,head2,&resultHead);
	    printf("Difference:");
	    printList(resultHead);
	}
	}
	else if((str1[0]==45)&& (str2[0]==45))
	{
	    if(num4>num3)
	    {
		addDigits(head1,head2,&resultHead);
		printf("Difference:-");
		printList(resultHead);
	    }
	    else
	    {
		addDigits(head2,head1,&resultHead);
		printf("Difference:-");
		printList(resultHead);
	    }

	}
	else if((str1[0]==45)&&(str2[0]>=48 && str2[0]<=57))
	{
	    if(num4>num3)
	    {
		subtractDigits(head1,head2,&resultHead);
		printf("Difference:-");
		printList(resultHead);
	    }
	    else
	    {
		subtractDigits(head2,head1,&resultHead);
		printf("Difference:");
		printList(resultHead);
	    }
	}
	else if((str1[0]>=48 &&str1[0]<=57) && (str2[0]==45))
	{
	    if(num4>num3)
	    {
		addDigits(head1,head2,&resultHead);
		printf("Difference:");
		printList(resultHead);
	    }
	    else
	    {
		addDigits(head2,head1,&resultHead);
		printf("Difference:-");
		printList(resultHead);
	    }
	}
    }
    else if(strcmp(operator,"*")==0)
    {
	
	Node *head1=stringToLinkedList(str1);
	Node *head2=stringToLinkedList(str2);

	if(str1[0]==45 || str2[0]==45)
	{
	multiplyDigits(head1,head2,&resultHead);
	printf("Product:-");
	printList(resultHead);
	}
	else
	{

	multiplyDigits(head1,head2,&resultHead);
	printf("Product:");
	printList(resultHead);
	}
    }
    else if(strcmp(operator,"/")==0)
    {
	Node *head1=stringToLinkedList(str1);
	Node *head2=stringToLinkedList(str2);
	DivideDigits(head1,head2,&resultHead);
	printf("Divide:");
	printList(resultHead);
    }
    else
    {
	printf("Invalid Operator\n");
    }
}



