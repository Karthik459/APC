#include<stdio.h>
#include<stdlib.h>
#include "operations.h"

int addDigits(Node*head1,Node*head2,Node**resultHead)
{
    Node *temp1=head1;
    Node *temp2=head2;

    while(temp1->next!=NULL)
    {
	temp1=temp1->next;
    }
    while(temp2->next!=NULL)
    {
	temp2=temp2->next;
    }
    int carry=0;

    while(temp1!=NULL ||temp2!=NULL)
    {
	int sum=carry;

	if(temp1!=NULL)
	{
	    sum+=temp1->data;
	    temp1=temp1->prev;
	}

	if(temp2!=NULL)
	{
	    sum+=temp2->data;
	    temp2=temp2->prev;
	}

	carry=sum/10;

	append(resultHead,sum%10);
    
    }
    while  (carry!=0 && temp1==NULL && temp2==NULL)
    {
	append(resultHead,carry%10);
	carry=carry/10;
    }
    return carry;
}

int subtractDigits(Node*head1,Node*head2,Node**resultHead)
{
    Node *temp1=head1;
    Node *temp2=head2;

    while(temp1->next!=NULL)
    {
	temp1=temp1->next;
    }
    while(temp2->next!=NULL)
    {
	temp2=temp2->next;
    }
    int borrow=0;

    while(temp1!=NULL || temp2!=NULL)
    {
	int diff=(temp1?temp1->data:0)-(temp2?temp2->data:0)-borrow;

	borrow=0;

	if(diff<0)
	{
	    diff+=10;
	    borrow=1;
	}

	append(resultHead,diff);

	if(temp1!=NULL)
	    temp1=temp1->prev;
	if(temp2!=NULL)
	    temp2=temp2->prev;
    }
    return borrow;
}

void multiplyDigits(Node*head1,Node*head2,Node**resultHead)
{
    int len1=1,len2=1;


    Node *temp1=head1;
    Node *temp2=head2;
    Node *temp3=head2;

    while(temp1->next!=NULL)
    {
	len1++;
	temp1=temp1->next;
    }
    while(temp2->next!=NULL)
    {
	len2++;
	temp2=temp2->next;
	temp3=temp3->next;
    }

    int result[len1+len2];

    for(int i=0;i<len1+len2;i++)
    {
	result[i]=0;
    }

    for(int i=0;temp1!=NULL;i++)
    {
	    temp2=temp3;
	for(int j=0;temp2!=NULL;j++)
	{
	    result[i+j]+=temp1->data*temp2->data;
	    result[i+j+1]+=result[i+j]/10;
	    result[i+j]%=10;
	    temp2=temp2->prev;
	}
	temp1=temp1->prev;
    }

    for(int i=0;i<len1+len2;i++)
    {
	append(resultHead,result[i]);
    }
}


void DivideDigits(Node*head1,Node*head2,Node**resultHead)
{
    int divident=0,divisor=0;
    Node *temp1=head1;
    Node *temp2=head2;

    while(temp1!=NULL)
    {
	divident=(divident*10)+temp1->data;
	temp1=temp1->next;
    }
    while(temp2!=NULL)
    {
	divisor=(divisor*10)+temp2->data;
	temp2=temp2->next;
    }
    int count=0;

    int sum=divisor;

    while(divisor<=divident)
    {
	divisor=divisor+sum;
	count++;
    }

    append(resultHead,count);
}
































  































































