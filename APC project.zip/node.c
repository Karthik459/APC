#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "node.h"

Node* createNode(int data)
{
    Node*newNode=(Node*)malloc(sizeof(Node));
    newNode->data=data;
    newNode->prev=newNode->next=NULL;
    return newNode;
}
void append(Node**head,int data)
{
    Node*newNode=createNode(data);
    if(*head==NULL)
    {
	*head=newNode;
    }
    else
    {
	Node*temp=*head;
	while(temp->next!=NULL)
	{
	    temp=temp->next;
	}
	temp->next=newNode;
	newNode->prev=temp;
    }
}

void printList(Node*head)
{
    Node *temp=head;

    while(temp->next!=NULL)
    {
	temp=temp->next;
    }
    while(temp!=NULL)
    {
	printf("%d",temp->data);
	temp=temp->prev;
    }
    printf("\n");
}

Node* stringToLinkedList(char *str)
{
    Node *head=NULL;
    for(int i=0;i<strlen(str);i++)
    {
	if(str[i]>=48 && str[i]<=57)
	append(&head,str[i]-'0');
    }
    return head;
}
