#ifndef OPERATORS_H

#define OPERATORS_H

#include "node.h"

int addDigits(Node*head1,Node*head2,Node**resultHead);
int subtractDigits(Node*head1,Node*head2,Node**resultHead);
void multiplyDigits(Node*head1,Node*head2,Node**resultHead);
void DivideDigits(Node*head1,Node*head2,Node**resultHead);

#endif



